/*package com.niit.SkillMapBackend;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.niit.model.Employee;
import com.niit.service.EmployeeServiceDao;
import com.niit.service.EmployeeServiceDaoImpl;

*//**
 * Hello world!
 *
 *//*
@Component
public class App 
{
    public static void main( String[] args )
    {
    	
    	EmployeeServiceDao service=new EmployeeServiceDaoImpl();
    	Employee employee= new Employee();
    	employee.setEmployeeId(100);
		employee.setGender("female");
		employee.setMobile("9786518898");
		employee.setName("priya");
		employee.setPassword("123");
		employee.setQualification("B.E");
		employee.setEmail("priya@gmail.com");
		employee.setRole("trainer");
		employee.setAddress("chennai");
		
    	
    	service.addEmployeeService(employee);
        System.out.println( "Hello World!" );
    }
}
*/